import React from 'react'

const ContactInfo = () => {
  return (
    <div>
      <p>Email: example@email.com</p>
      <p>Phone: +624324123</p>
      <p>Address: xyz street, indonesia</p>
    </div>
  )
}

export default ContactInfo
