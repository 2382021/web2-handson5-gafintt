import React from 'react'

const Jobs = () => {
  return (
    <div>Jobs Page</div>
  )
}

export default Jobs
